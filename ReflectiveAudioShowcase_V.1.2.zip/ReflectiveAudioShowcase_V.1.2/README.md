# Reflective Audio 2D, release v1.2

Room acoustics for 2D tilemap games in Unity and FMOD. Rays from the listener measure the room around the player, and the measurements drive the reverb, directional early reflections and echoes in real time. It also includes an authored-zone baseline and a Steam Audio reference to compare against.

By Tyler Crump, COMP3180 Final Project, Macquarie University, 2026.

## What's in this release

| File | What it is | Do you need it? |
|---|---|---|
| `ReflectiveAudio2D.unitypackage` | The Unity side: scripts, the demo player, and a menu that builds a demo scene | Yes |
| `ReflectiveAudio2D_FMODProject.zip` | The FMOD Studio side: return buses, delays, panning, snapshots, global parameters, automation, and a few test sounds | Yes, unless you'll rebuild the routing in your own FMOD project |
| `README.md` | This file | |

They're two halves of one system. The Unity scripts drive FMOD through bus paths and global parameters, and the FMOD project is where those buses and parameters live.

## Requirements

- Unity 6 (built with 6000.3.10f1); a 2D URP project suits the demo
- FMOD Studio **2.03** and FMOD for Unity **2.03** (the versions must match)
- The Input System package (the old Input Manager also works)
- *Optional, Condition C only:* Steam Audio's Unity package and FMOD Studio plugin, from Valve's Steam Audio GitHub releases (built with Steam Audio 4.8.1). Not included here.

## Setup, step by step

**1. FMOD project**
1. Unzip `ReflectiveAudio2D_FMODProject.zip` somewhere permanent. FMOD for Unity will point at this folder.
2. Open the `.fspro` file in FMOD Studio 2.03. Its **Steam Audio Reverb** return uses Steam Audio's FMOD plugin. If you won't install Steam Audio, delete that effect from the return and keep the return itself. Otherwise Unity can't load the Master bank (`ERR_PLUGIN_MISSING`).
3. Build the banks with **File → Build** (F7).

**2. Unity project**
1. Install the Input System and FMOD for Unity 2.03.
2. Under **FMOD → Edit Settings**, set the source to *FMOD Studio Project* and choose the `.fspro` from step 1.
3. Choose **Assets → Import Package → Custom Package…** and select `ReflectiveAudio2D.unitypackage`. The Console should show no errors.

**3. Try the demo**
1. Run **Tools → Reflective Audio 2D → Create Demo Scene**. This builds five rooms of known size, a stand-in player and the listener rig.
2. On **Player → Demo Player 2D**, set **Impact Event** to one of the test events.
3. For Condition A, set each zone's **Zone Snapshot** under **Acoustic Zones (Condition A)** to the matching snapshot (the outdoor zone needs none). Then save the scene.
4. Press **Play**:
   - **A / D** walk and **Space** jumps.
   - **Left-click a wall** to fire at it.
   - **7 / 8 / 9** switch between conditions A, B and C.

The demo starts in **Condition B**. Fire at the far wall in each room: the echo arrives later and quieter as the room gets bigger, and it comes from the side it bounced off. Press **7** to hear the authored-zone baseline for comparison.

**4. Condition C, Steam Audio (optional)**

Create Demo Scene sets up Conditions A and B. Condition C needs these extra steps:

1. **Install Steam Audio 4.8.1**: the Unity package and its FMOD Studio integration for Unity, which provides `phonon_fmod.dll`. In Steam Audio's settings, set **Audio Engine** to **FMOD Studio**.
2. **Load the FMOD plugin.**
   1. Choose **Assets → Create → Reflective Audio 2D → Steam Audio FMOD Plugin Loader**.
   2. Drag the new asset into **FMOD → Edit Settings → Callback Handler**.
   3. Remove `phonon_fmod` from **Dynamic Plugins** if it's listed.
   4. On the asset, check that **Editor Folder** is the folder holding `phonon_fmod.dll`, and **Editor Dependency Folder** the folder holding `phonon.dll`. Both are relative to `Assets`.
   5. Press Play. The Console should show `[SteamAudioFmodPluginLoader] Loaded phonon_fmod.dll`.
3. **Build the proxy mesh.**
   1. Create an empty GameObject at (0, 0, 0) called *Acoustic Proxy* and add **Tilemap Acoustic Proxy** to it.
   2. Drag the **Walls** object's Composite Collider 2D into its **Source Collider** field.
   3. Right-click the component header and choose **Build Acoustic Mesh**.
4. **Export the geometry.** Add **Steam Audio Geometry** to *Acoustic Proxy*, with a material such as Concrete, then run **Steam Audio → Export Active Scene**. Export again whenever the walls change.
5. **Add the listener.** On **Player → Listener**, add **Steam Audio Listener** and tick **Apply Reverb**.
6. **Hand the proxy to the Condition Manager.** Add *Acoustic Proxy* to its **Steam Audio Objects** list, so the proxy is only active in Condition C.
7. **Test it.** Press Play, press **9**, and fire in the hall.

**Not using Steam Audio?** The FMOD project's **Steam Audio Reverb** return holds Steam Audio's plugin effect. Without the plugin, Unity can't load the Master bank at all: you get `Missing DSP plugin 'Steam Audio Reverb'`, then `ERR_PLUGIN_MISSING`. In FMOD Studio, delete that effect from the return, keep the return itself, and rebuild. Conditions A and B then work, and C stays silent.

## The three conditions

| | Condition | How the room sound is made |
|---|---|---|
| A | Zone baseline | Hand-placed trigger zones fade FMOD snapshots in and out |
| B | Raycast dynamic | A ring of rays sets the reverb, three taps give the left, right and ceiling reflections, and image-source echoes cover sounds made away from the player |
| C | Steam Audio | Steam Audio simulates the room from a 3D mesh extruded from the tilemap collider |

## Using it in your own game

`Assets/ReflectiveAudio2D/README.md`, which you get after importing the package, has the full guide:
- the components to put on the player
- the exact bus names and global parameters your FMOD project needs
- how to use echoes for your own sounds
- how to set up Steam Audio

## Known limitations

- **One FMOD project.** The mixer lives in the Master bank, and banks from two different FMOD projects can't be combined. Either start from this FMOD project, or rebuild its buses and parameters in your own (see the full guide).
- The system assumes axis-aligned walls, as on a tilemap, and models only first-order echoes (one bounce per wall).
- The demo's test sounds are only for trying the system. Use your own sounds in a real game.

## Credits

FMOD Studio by Firelight Technologies, Steam Audio by Valve, Unity by Unity Technologies. The image-source echoes follow Allen & Berkley (1979).